const menubtn = document.getElementById('menu-btn')
const menubox = document.getElementById('menu-box')
const closebtn = document.querySelector('.close-menu')
const body = document.querySelector('.menuback')
function now() {
  menubox.style.right = '0px'
}
//menubox.style.right = '-400px'
menubtn.addEventListener('click',()=>{
  now()
  body.style.display = 'block'
  body.style.zIndex = '5'
  body.style.position = 'fixed'
  menubtn.style.opacity = '0'
})

closebtn.addEventListener('click',()=>{
  menubox.style.right = '-320px'
  body.style.display = 'none'
  menubtn.style.opacity = '1'
})

body.addEventListener('click',()=>{
  menubox.style.right = '-320px'
  body.style.display = 'none'
  menubtn.style.opacity = '1'
})
